from classes import Pessoa
#São os outros ficherios da classe de pessoas

from classes import Mota
#Os outros ficherios da classe da mota

pessoa = Pessoa("Dr. Jubiscreldo", 100)
#Informação da pessoa, nome e idade

mota = Mota("Kawasaki", "z1000r")
#Informação da mota, marca e modelo
 
print(pessoa.saudacao())
#Imprime as informações da pessoa(ll.8 e 9)

print(mota.informacao_da_mota())
#Imprime as informações da mota(ll.18 e 19)
#!FIMMM disto tudo!