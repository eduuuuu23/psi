class Pessoa:
#Sobre a pessoa, neste temos que no outro ficheiro falar as informações da pessoa
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade

#Diz o nome e a idade da pessoa
    def saudacao(self):
        return f"O meu nome é {self.nome} e tenho {self.idade} anos!"

#Sobre a mota, temos que no outro ficheiro falar o modelo e a marca da mota
class Mota:
    def __init__(self, marca, modelo):
        self.marca = marca
        self.modelo = modelo

#Diz o modelo e a marca da mota 
    def informacao_da_mota(self):
        return f"Ele tem uma {self.marca} {self.modelo}."
#!Fimmm!deste ficheiro